---
layout: article
title: Python Melesat di Daftar Bahasa Pemrograman Yang Paling Populer
---

---

Menurut Indeks Tiobe untuk September 2018, Java, C, dan Python adalah bahasa pemrograman paling populer di dunia.

Bahasa populer lainnya termasuk Visual Basic .NET dan C ++, yang baru saja kehilangan tempat ketiga di peringkat ke Python.

Tiobe mencatat bahwa ini adalah pertama kalinya dalam sejarah bahwa Python telah memasuki tiga bahasa pemrograman teratas dalam peringkat Tiobe.

Tiobe menyatakan bahwa peningkatan signifikan Python dalam popularitas dapat dikaitkan dengan aksesibilitas dan kemudahan penggunaannya.

Peringkat PYPL menunjukkan Python di bagian atas daftar, diikuti oleh Java dan JavaScript.

### Ranking Bahasa Pemrograman Populer Bulan September

22 bahasa pemrograman teratas untuk September 2018, menurut peringkat Tiobe Index dan PYPL, selengkapnya lihat gambar dibawah ini.

![Python Bahasa Pemrograman Populer](/images/posts/bahasa-pemrograman-populer.png "Bahasa Terpopuler September 2018")

*- Penulis* [gdkllr](https://github.com/gdkllr)
