---
layout: article
title: Source untuk belajar python
date: 2020-10-26 06:28:20
categories: artikel
---

---
Python menjadi salah satu bahasa pemrograman yang paling diminati saat ini. seperti dilansir dari situs [The Redmonk](https://redmonk.com/sogrady/2020/07/27/language-rankings-6-20/) python menduduki peringkat kedua setelah javascript. Karena banyaknya pengguna bahasa python, mungkin ini yang membuat developer python lebih semangat untuk meningkatkan performa bahasa python. Supaya tidak ketinggalan tren python mau tidak mau ya kita harus terus belajar, maka dari itu di artikel ini saya ingin mencoba berbagi beberapa referensi sumber yang saya gunakan untuk belajar bahasa python. Ps: kalian bisa menambahkan sumber lain yang kalian punya ke artikel ini.
![Redmon rank](https://github.com/nardiyansah/belajarpython.com/blob/nardiyansah-article-1/images/redmonk%20rank.png)

---
# 1. realpython.com
realpython.com adalah situs belajar pemrograman python berbahasa Inggris. Di situs ini kamu bisa mengikuti tutorial untuk project-project kecil, kamu bisa baca artikel tentang bahasa pemrograman, kamu juga bisa subscribe email realpython jika kamu ingin dikirimi email berita terbaru tentang bahasa pemrograman python. Ada juga video kursus nya sehingga kamu bisa belajar python step-by-step. Lalu ada Kuis dimana kamu bisa mengecek progress skill python kamu. Dan yang paling bagus menurutku adalah fitur learning path di situs ini, jadi kamu bisa fokus belajar ke bidang keahlian yang ingin kamu tekuni misalkan kamu ingin menjadi python web developer atau data scientist. ![realpython.com](https://github.com/nardiyansah/belajarpython.com/blob/nardiyansah-article-1/images/realpython.png)

# 2. belajarpython.com
kalau tadi sudah yang berbahasa Inggris, kayaknya kita juga harus memiliki sumber referensi belajar yang menggunakan bahasa sehari-hari kita sendiri. Salah satunya adalah situs dimana artikel ini dibuat yaitu belajarpython.com. Di situs ini kamu bisa belajar dengan mengikuti tutorial yang sudah dibuat hasil dari kontribusi para kontributor (situs ini open source) dan membaca artikel tentang python, yang pasti itu semua ditulis dengan bahasa Indonesia jadi jangan takut untuk belajar pemrogaman karena merasa tidak bisa bahasa Inggris. ![belajarpython.com](https://github.com/nardiyansah/belajarpython.com/blob/nardiyansah-article-1/images/belajarpython.png)

---
mungkin baru sedikit sumber yang bisa saya berikan karena situs ini yang sudah saya coba langsung. Jika teman-teman memiliki sumber lain silahkan masukkan ke artikel ini. Mari kita saling berbagi!.
