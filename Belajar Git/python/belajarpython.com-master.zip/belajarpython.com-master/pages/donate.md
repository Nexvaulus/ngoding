---
layout: blank-page
title: Donasi
permalink: /donate/
---

---
Belajarpython adalah website referensi panduan bahasa pemrograman Python No.1 di Indonesia. Misi kami adalah menyediakan tutorial bahasa pemrograman python dalam bahasa Indonesia yang mudah diakses dan digunakan secara gratis oleh semua orang

Iklan bukanlah sesuatu hal yang jahat, kami hanya tidak menginginkan pembaca terganggu dengan adanya iklan saat membaca tutorial. Tetapi walau bagaimanapun kami tetap membutuhkan biaya untuk merawat dan melakukan inovasi untuk kelangsungan website Belajarpython.

Untuk itu setiap donasi dari Anda sangat berharga bagi kelangsungan website Belajarpython dan kelangsungan media pembelajaran gratis di Indonesia.

#### Donasi Dengan Bitcoin
![Alamat Bitcoin Belajarpython](/images/qr-code.png "Alamat Bitcoin Belajarpython")

###### Bitcoin Address
[**1PMoJPzhuizdcay3rKhotDBkEqqbsRjwUw**](https://blockchain.info/address/1PMoJPzhuizdcay3rKhotDBkEqqbsRjwUw)

#### Kenapa Donasi Belajarpython ?
- Anda turut serta membantu setiap orang mempelajari bahasa pemrograman Python.
- Anda turut serta membantu setiap orang mendapatkan ilmu untuk bekal mendapatkan pekerjaan.
- Anda turut serta membantu organisasi non-profit agar tetap berjalan
- Anda turut serta meningkatkan taraf pendidikan di Indonesia

#### Apa yang akan kami lakukan terhadap donasi yang terkumpul ?
- Menjaga dan merawat kelangsungan website Belajarpython serta melakukan inovasi.
- Melakukan event/acara untuk memperkenalkan dan mengajarkan pemrograman Python di Indonesia
- Untuk penambahan staf pengelola dan mempertahankan pengelola yang sudah ada di website Belajarpython

> [Purwanto](https://github.com/purwnt) - Author Belajarpython